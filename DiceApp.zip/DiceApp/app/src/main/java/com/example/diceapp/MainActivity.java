package com.example.diceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.Random;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RadioGroup radioGroup;
    RadioButton radioButton;
    TextView textView;
    private int numSide = 0;
    private int dicenumber = 0;
    private int count;

    private Random et = new Random();
    EditText editText;
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        textView = (TextView) findViewById(R.id.t1);
        editText=(EditText) findViewById(R.id.addnumber);

        button = findViewById(R.id.buttonroll);
        button.setOnClickListener(this);



    }


    public void roll()
    {
        String x = editText.getText().toString();
        int et =  Integer.parseInt(x);

        count = (int) (Math.random() * et+ 1);
        String cc = String.valueOf(count);

        textView.setText(cc);
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.rd6:
                if (checked)
                    dicenumber = (int) (Math.random() * 6 + 1);
                String r1 = String.valueOf(dicenumber);
                textView.setText(r1);
                break;
            case R.id.rd8:
                if (checked)

                    dicenumber = (int) (Math.random() * 8 + 1);
                String r2 = String.valueOf(dicenumber);
                textView.setText(r2);
                break;
            case R.id.rd10:
                if (checked)

                    dicenumber = (int) (Math.random() * 10 + 1);
                String r10 = String.valueOf(dicenumber);
                textView.setText(r10);
                break;

            case R.id.rd12:
                if (checked)

                    dicenumber = (int) (Math.random() * 12 + 1);
                String r3 = String.valueOf(dicenumber);
                textView.setText(r3);
                break;

            case R.id.rd20:
                if (checked)
                    dicenumber = (int) (Math.random() * 20 + 1);
                String r4= String.valueOf(dicenumber);
                textView.setText(r4);
                break;
            case R.id.rd4:
                if (checked)
                    dicenumber = (int) (Math.random() * 4 + 1);
                String r5 = String.valueOf(dicenumber);
                textView.setText(r5);
                break;

        }
    }


    @Override
    public void onClick(View v) {
        switch(v.getId() ) {
            case R.id.buttonroll:
            roll();
            break;
        }
    }
}





